Minetest Game mod: stairs
=========================
See license.txt for license information.

Authors of source code
----------------------
Originally by Kahrl <kahrl@gmx.net> (LGPLv2.1+) and
celeron55, Perttu Ahola <celeron55@gmail.com> (LGPLv2.1+)
Various Minetest Game developers and contributors (LGPLv2.1+)

Authors of media (textures)
---------------------------

Textures
--------
Copyright (c) 2018 Shara RedCat (CC BY-SA 3.0):
  Derived from a texture by PilzAdam (CC BY-SA 3.0):
    stairs_obsidian_glass_outer_stairside.png
    stairs_obsidian_glass_stairside.png

Copyright (c) 2018 TumeniNodes (CC BY-SA 3.0):
  Derived from a texture by celeron55 (CC BY-SA 3.0) and
      converted to bright white by Krock (CC BY-SA 3.0):
    stairs_glass_stairside.png
    stairs_glass_split.png
  Derived from a texture by PilzAdam (CC BY-SA 3.0):
    stairs_obsidian_glass_split.png
